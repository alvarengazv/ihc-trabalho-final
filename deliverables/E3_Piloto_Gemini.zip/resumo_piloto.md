# Piloto de instrumentação

Resultados sintéticos recalculados sobre cada registro de execução. A referência é um percurso independente de R na mesma versão e ampliação inicial. Cada linha representa uma sessão.

| Tarefa | Versão | Executor | S | A | Toques | Desloc. | Nref | R_A | D | V | O | Erros E1–E6 | U |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| C1 | A | C | — | 13 | 7 | 6 | 8 | 1,62 | 6 | 1,33 | 0,667 | 1 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | C | 0 | 150 | 90 | 60 | 8 | 18,8 | 60 | 19,3 | 0,667 | 1 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | C | — | 7 | 3 | 4 | 8 | 0,875 | 4 | 0,333 | 0,667 | 1 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | C | — | 78 | 46 | 32 | 8 | 9,75 | 32 | 10 | 0,667 | 1 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | C | — | 0 | 0 | 0 | 8 | 0 | — | 0 | 1 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | C | — | 13 | 7 | 6 | 8 | 1,62 | 6 | 1,33 | 0,667 | 1 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | A | R | 1 | 8 | 5 | 3 | 8 | 1 | 1 | 0 | 0 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |
| C1 | B | C | 0 | 150 | 149 | 1 | 7 | 21,4 | 0,333 | 32 | 0 | 0 / 0 / 47 / 0 / 0 / 0 | 0 |
| C1 | B | R | 1 | 7 | 6 | 1 | 7 | 1 | 0,333 | 0,333 | 0 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |
| C2 | A | C | 1 | 3 | 3 | 0 | 3 | 1 | 0 | 0 | 0 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |
| C2 | A | R | 1 | 3 | 3 | 0 | 3 | 1 | 0 | 0 | 0 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |
| C2 | B | C | — | 64 | 64 | 0 | 3 | 21,3 | 0 | 0 | 0 | 0 / 0 / 31 / 0 / 0 / 0 | 0 |
| C2 | B | R | 1 | 3 | 3 | 0 | 3 | 1 | 0 | 0 | 0 | 0 / 0 / 0 / 0 / 0 / 0 | 0 |

## Taxas de erro por oportunidade

Cada célula mostra erros/oportunidades (taxa). O travessão identifica taxa indefinida. As oportunidades de E1 e E3 contam as escolhas efetivamente registradas. As de E5 contam as discrepâncias introduzidas no protocolo.

| Tarefa / versão / executor | E1 | E2 | E3 | E4 | E5 | E6 |
|---|---|---|---|---|---|---|
| C1 / A / C | 1/2 (0,5) | 0/0 (—) | 0/0 (—) | 0/6 (0) | 0/0 (—) | 0/0 (—) |
| C1 / A / C | 1/30 (0,0333) | 0/0 (—) | 0/0 (—) | 0/60 (0) | 0/0 (—) | 0/0 (—) |
| C1 / A / C | 1/1 (1) | 0/0 (—) | 0/0 (—) | 0/4 (0) | 0/0 (—) | 0/0 (—) |
| C1 / A / C | 1/15 (0,0667) | 0/0 (—) | 0/0 (—) | 0/32 (0) | 0/0 (—) | 0/0 (—) |
| C1 / A / C | 0/0 (—) | 0/0 (—) | 0/0 (—) | 0/0 (—) | 0/0 (—) | 0/0 (—) |
| C1 / A / C | 1/2 (0,5) | 0/0 (—) | 0/0 (—) | 0/6 (0) | 0/0 (—) | 0/0 (—) |
| C1 / A / R | 0/1 (0) | 0/0 (—) | 0/1 (0) | 0/3 (0) | 0/0 (—) | 0/0 (—) |
| C1 / B / C | 0/48 (0) | 0/0 (—) | 47/48 (0,979) | 0/1 (0) | 0/0 (—) | 0/0 (—) |
| C1 / B / R | 0/1 (0) | 0/0 (—) | 0/1 (0) | 0/1 (0) | 0/0 (—) | 0/0 (—) |
| C2 / A / C | 0/0 (—) | 0/0 (—) | 0/1 (0) | 0/0 (—) | 0/1 (0) | 0/0 (—) |
| C2 / A / R | 0/0 (—) | 0/0 (—) | 0/1 (0) | 0/0 (—) | 0/1 (0) | 0/0 (—) |
| C2 / B / C | 0/0 (—) | 0/0 (—) | 31/63 (0,492) | 0/0 (—) | 0/1 (0) | 0/0 (—) |
| C2 / B / R | 0/0 (—) | 0/0 (—) | 0/1 (0) | 0/0 (—) | 0/1 (0) | 0/0 (—) |

## Agregação por condição

| Tarefa / versão / executor | Iniciadas | S médio entre execuções sem falha técnica | Mediana de A | Proporção com ajuda por camada (1 / 2 / 3) |
|---|---:|---:|---:|---|
| C1 / A / C | 6 | 0 | 13 | 0 / 0 / 0 |
| C1 / A / R | 1 | 1 | 8 | 0 / 0 / 0 |
| C1 / B / C | 1 | 0 | 150 | 0 / 0 / 0 |
| C1 / B / R | 1 | 1 | 7 | 0 / 0 / 0 |
| C2 / A / C | 1 | 1 | 3 | 0 / 0 / 0 |
| C2 / A / R | 1 | 1 | 3 | 0 / 0 / 0 |
| C2 / B / C | 1 | — | 64 | 0 / 0 / 0 |
| C2 / B / R | 1 | 1 | 3 | 0 / 0 / 0 |

## Comparação com o método especialista

A HTA prevê cinco toques em C1/A, seis em C1/B e três em C2/A e B. A inclui também deslocamentos ou mudanças de ampliação. Pela aproximação especialista do caderno E1, três acionamentos independentes de C2 correspondem a 3 × (1,35 + 1,10 + 0,20) = 7,95 s de preparação, apontamento e acionamento, sob a premissa de alvos localizados. A razão R_A compara contagens de ações do mesmo percurso geométrico. A latência e o tempo de relógio do registro não medem o desempenho humano.

## Proveniência

- [C1-A-C-42-4cfc3ee12f4f.json](logs/C1-A-C-42-4cfc3ee12f4f.json)
- [C1-A-C-42-4d1050d0a165.json](logs/C1-A-C-42-4d1050d0a165.json)
- [C1-A-C-42-908810b81d7d.json](logs/C1-A-C-42-908810b81d7d.json)
- [C1-A-C-42-a89e95ec43bb.json](logs/C1-A-C-42-a89e95ec43bb.json)
- [C1-A-C-42-c4c930e6149a.json](logs/C1-A-C-42-c4c930e6149a.json)
- [C1-A-C-42-f984fea2305b.json](logs/C1-A-C-42-f984fea2305b.json)
- [C1-A-R-42-860b2fa789cb.json](logs/C1-A-R-42-860b2fa789cb.json)
- [C1-B-C-42-ecf2670e1f5b.json](logs/C1-B-C-42-ecf2670e1f5b.json)
- [C1-B-R-42-0d3c0d41b2d6.json](logs/C1-B-R-42-0d3c0d41b2d6.json)
- [C2-A-C-42-840b102d725e.json](logs/C2-A-C-42-840b102d725e.json)
- [C2-A-R-42-03b182dc7c40.json](logs/C2-A-R-42-03b182dc7c40.json)
- [C2-B-C-42-aa6ab1828dcb.json](logs/C2-B-C-42-aa6ab1828dcb.json)
- [C2-B-R-42-186e07533f8a.json](logs/C2-B-R-42-186e07533f8a.json)

## Chamadas ao Gemini

Foram concluídas 3 de 16 condições planejadas. O diretório de auditoria contém 486 tentativas de requisição, com 478 respostas registradas. Falhas técnicas aparecem como registros distintos, com S indefinido.

Modelo solicitado: gemini-3.5-flash-lite. Versões retornadas: gemini-3.5-flash-lite. Semente local e da API: 42. Uma execução por condição serve à calibração e não estima uma distribuição de desempenho.
