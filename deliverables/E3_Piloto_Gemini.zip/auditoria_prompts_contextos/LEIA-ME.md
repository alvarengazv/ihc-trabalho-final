# Auditoria do contexto enviado

Cada diretório de sessão contém os arquivos de tentativa com o corpo da requisição, a observação, a resposta do provedor quando recebida, a latência e a identificação do modelo. As quatro sessões R não geraram chamadas. Consulte protocolo_gemini.json para a matriz prevista e resumo_piloto.md para o que foi observado.
